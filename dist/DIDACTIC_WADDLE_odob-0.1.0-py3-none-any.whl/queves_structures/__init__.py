from queves_structures import queve_list
from queves_structures import queve_deque
from queves_structures import queve_queve
